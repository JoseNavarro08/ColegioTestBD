package colegio;
public class Colegio {
    public static void main(String[] args) {
        
    }
    
}
