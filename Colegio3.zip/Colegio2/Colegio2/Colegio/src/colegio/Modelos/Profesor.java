package colegio.Modelos;
public class Profesor extends Usuario {
    public Profesor(int id, String nombre, String correo, String contrasena) {
        super(id, nombre, correo, contrasena);
    }
}