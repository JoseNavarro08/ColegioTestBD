package colegio.Controladores;
import colegio.Modelos.Tarea;
import java.util.List;

public class TareaControlador {
    public boolean asignarTarea(Tarea tarea) {
        // Lógica para asignar una tarea a un estudiante
        return true;
    }

    public List<Tarea> obtenerTareasPorEstudiante(int estudianteId) {
        // Lógica para obtener todas las tareas de un estudiante
        return null;
    }
}
